package com.commonMethods;

public interface FrameworkConstants {
	
	String CONFIG_FILE_PATH = "C:/Users/Itsqe/IdeaProjects/TestAutomationFramework/config.properties";
	
	String POSTRequest_AUTH_DEFAULT_REQUEST = "C:/Users/Itsqe/IdeaProjects/TestAutomationFramework/testData/PostRequest_Auth.txt";
	
	String DATA_FILE_PATH = "C:/Users/Itsqe/IdeaProjects/TestAutomationFramework/testData/TestData.xlsx";
	
}
